This example implements a minimal (non-RFC-compliant) HTTP server. It demonstrates how
to use Actor Guild to implement a server.

To test the server, start the Main class and point your browser at http://localhost:8000

