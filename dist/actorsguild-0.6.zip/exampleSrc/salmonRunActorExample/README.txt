This example is the Actors Guild version of a simple test for actor frameworks.
See
http://sujitpal.blogspot.com/2009/01/more-java-actor-frameworks-compared.html