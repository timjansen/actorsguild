Actors Guild
=============
Version 0.6

For more information on Actors Guild, please visit
http://actorsguildframework.org


Archive content
================
 - ag-0.6.jar: the binary distribution. 
 - external-lib/asm/asm-3.1.jar: the ASM library (http://asm.objectweb.org). 
 - external-lib/asm/LICENSE.txt: license of ASM
 - exampleSrc/: example code
 - ag-0.6.src.zip: the source code.
 - LICENSE.txt: the license of Actors Guild (Apache License 2)
 
 
 How to use it
 ==============
 In order to write applications that use Actors Guild, or to run the examples, 
 you only need
  - Java VM 1.5 or higher
  - ag-0.6.jar in your classpath
  - asm-3.1.jar in your classpath
  
 